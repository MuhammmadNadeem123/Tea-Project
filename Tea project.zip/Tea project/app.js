//   


document.querySelector('.nav_btn').addEventListener('click', showNav);


function showNav () {
    document.querySelector('.nav_links').classList.toggle('show_links'); 
}